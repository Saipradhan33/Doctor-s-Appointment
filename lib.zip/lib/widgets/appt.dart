import 'package:flutter/material.dart';
class Appt extends StatelessWidget {
  const Appt({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointments'),
      ),
      body: Text('Huulluuu'),
    );
  }
}
