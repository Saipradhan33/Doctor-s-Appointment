import 'package:doct_appointment/widgets/appt.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final user=FirebaseAuth.instance.currentUser;
  signout() async{
    await
    FirebaseAuth.instance.signOut();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Walahh'),
        leading: Builder(
            builder: (context) => IconButton(
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                } , icon: Icon(Icons.menu)
            )
        ),
      ),
      drawerEnableOpenDragGesture: true,
      drawer: Drawer(
        child: Column(
          children: [
            UserAccountsDrawerHeader( accountName: Text('${user?.displayName}'), accountEmail: Text('${user?.email}'),
            currentAccountPicture: CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(FirebaseAuth.instance.currentUser?.photoURL?? ''),
            ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text("Home"),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: Icon(Icons.calendar_month),
              title: Text("Appointment"),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => Appt()))
            ),
            ListTile(
              leading: Icon(Icons.logout_rounded),
              title: Text("Log out"),
              onTap: () => signout(),
            )
          ],
        ),
      ),
      body: Center(
        child: Text('Welcome'),
      ),
    );
  }
}
